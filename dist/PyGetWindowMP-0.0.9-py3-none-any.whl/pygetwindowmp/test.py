import pygetwindowmp as gw

titles = ["Presentación de PowerPoint - Google Chrome", "Nueva pestaña - Google Chrome"]

titles = list(filter(lambda t: t != "", titles))
windows = gw.getAllWindows()
for win in windows:
    if win.title and win.title in titles:
        win.close()
        titles.remove(win.title)
        if not titles:
            break
