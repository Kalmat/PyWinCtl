import time
import win32gui
import pywinctl as pwc

print("Open notepad and press Ctl-C when you're done")
while True:
    try:
        time.sleep(1)
    except KeyboardInterrupt:
        break
print("Click on notepad and keep it as the active window")
for i in range(5, 0, -1):
    try:
        print("You have %s seconds remaining" % str(i))
        time.sleep(1)
    except KeyboardInterrupt:
        break
win = pwc.getActiveWindow()
hWnd = win.getHandle()
print("Window handle:", hWnd, win32gui.GetWindowText(hWnd))
hMenu = win32gui.GetMenu(hWnd)
print("Menu handle:", hMenu)
