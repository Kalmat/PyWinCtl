import pywinctl as pwc
import pywinauto
from pywinauto import Application
import win32api
import win32gui
import win32con
import win32process


def isFlashing(name) -> bool:

    def _getFileDescription(handle):
        # https://stackoverflow.com/questions/31118877/get-application-name-from-exe-file-in-python

        _, pid = win32process.GetWindowThreadProcessId(handle)
        hProc = win32api.OpenProcess(win32con.PROCESS_QUERY_INFORMATION | win32con.PROCESS_VM_READ, 0, pid)
        exeName = win32process.GetModuleFileNameEx(hProc, 0)

        try:
            language, codepage = win32api.GetFileVersionInfo(exeName, '\\VarFileInfo\\Translation')[0]
            stringFileInfo = u'\\StringFileInfo\\%04X%04X\\%s' % (language, codepage, "FileDescription")
            description = win32api.GetFileVersionInfo(exeName, stringFileInfo)
        except:
            description = "unknown"

        return description

    def _find_taskbar_icon(hWnd):

        exStyle = win32api.GetWindowLong(hWnd, win32con.GWL_EXSTYLE)
        owner = win32gui.GetWindow(hWnd, win32con.GW_OWNER)
        if exStyle & win32con.WS_EX_APPWINDOW != 0 or owner != 0:
            return None

        name = _getFileDescription(hWnd)

        try:
            app: pywinauto.Application = Application(backend="uia").connect(path="explorer.exe")
            sysTray: pywinauto.WindowSpecification = app.window(class_name="Shell_TrayWnd")
            w: pywinauto.WindowSpecification = sysTray.child_window(title_re=name, found_index=0)
            rect = w.rectangle()
        except:
            rect = None
        return rect

    w = pwc.getWindowsWithTitle(name, condition=pwc.Re.CONTAINS)
    hWnd = w[0].getHandle()

    iconRect = _find_taskbar_icon(hWnd)
    if iconRect:

        xPos = iconRect.left + int((iconRect.right - iconRect.left) / 2)
        color = 0
        desktop = win32gui.GetDesktopWindow()
        dc = win32gui.GetWindowDC(desktop)
        for i in range(50, 54):
            color += win32gui.GetPixel(dc, xPos, iconRect.top + i)
        win32gui.ReleaseDC(desktop, dc)
        flashColor = 10787327  # This value is totally empirical. Find a way to retrieve it!!!!
        if color / 4 == flashColor:
            return True
        else:
            return False
    else:
        return False


print("FLASHING?", isFlashing("Spotify"))
