import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GObject

gi.require_version('testShared', '0.1')
from gi.repository import testShared


class GUI (Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        pb = testShared.CircularProgressBar()
        pb.props.percentage = 0.6
        self.connect('destroy', self.on_window_destroy)
        self.add(pb)
        self.show_all()
        Gtk.main()

    def on_window_destroy(self, window):
        Gtk.main_quit()


if __name__ == "__main__":
    GUI()
