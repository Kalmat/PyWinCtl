import ctypes
import subprocess
import sys
import time

import pywinctl as pwc
from pywinctl import Rect

if sys.platform == "win32":
    import win32gui
    dpiAware = ctypes.windll.user32.GetAwarenessFromDpiAwarenessContext(ctypes.windll.user32.GetThreadDpiAwarenessContext())
    if dpiAware == 0:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)

print(pwc.getAllScreens())
print()

npw = pwc.getActiveWindow()
print(npw.title)
print()


def _getWindowRect(winIn):

    if sys.platform == "win32":
        x, y, r, b = win32gui.GetWindowRect(winIn.getHandle())

    elif sys.platform.lower() == "linux":
        win = winIn._xWin
        geom = win.get_geometry()
        x = geom.x
        y = geom.y
        w = geom.width
        h = geom.height
        while True:
            parent = win.query_tree().parent
            pgeom = parent.get_geometry()
            x += pgeom.x
            y += pgeom.y
            if parent.id == winIn._rootWin.id:
                break
            win = parent
        r = x + w
        b = y + h

    else:
        cmd = """on run {arg1, arg2}
                    set procName to arg1
                    set winName to arg2
                    set appBounds to {{0, 0}, {0, 0}}
                    try
                        tell application "System Events" to tell application process procName
                            set appBounds to {position, size} of window winName
                        end tell
                    end try
                    return appBounds
                end run"""
        proc = subprocess.Popen(['osascript', '-', winIn.getAppName(), winIn.title],
                                stdin=subprocess.PIPE, stdout=subprocess.PIPE, encoding='utf8')
        ret, err = proc.communicate(cmd)
        if not ret:
            ret = "0, 0, 0, 0"
        r = ret.replace("\n", "").strip().split(", ")
        x, y, w, h = (int(r[0]), int(r[1]), int(r[2]), int(r[3]))
        r = x + w
        b = y + h

    return Rect(x, y, r, b)


def on_move(pos):
    myRect = npw.rect
    theirRect = _getWindowRect(npw)
    print("DIFF!!" if myRect != theirRect else "", myRect, theirRect, npw.box)


npw.watchdog.start(movedCB=on_move)

while True:
    try:
        time.sleep(0.1)
    except KeyboardInterrupt:
        break
