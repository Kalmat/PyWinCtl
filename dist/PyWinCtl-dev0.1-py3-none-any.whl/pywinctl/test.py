import pywinctl as pwc
import Xlib.display

display = Xlib.display.Display()
screen = display.screen()
root = screen.root


def getWindowRect(win, ewmhwin):
    geom = win.get_geometry()
    x = geom.x
    y = geom.y
    w = geom.width
    h = geom.height
    while True:
        parent = win.query_tree().parent
        pgeom = parent.get_geometry()
        x += pgeom.x
        y += pgeom.y
        if parent.id == root.id:
            break
        win = parent
    net_extents = ewmhwin._getNetFrameExtents()
    if net_extents and len(net_extents) >= 4:
        x = x - net_extents[0]
        y = y - net_extents[2]
        w = w + net_extents[0] + net_extents[1]
        h = h + net_extents[2] + net_extents[3]
    return x, y, w, h


w = pwc.getActiveWindow()
print(getWindowRect(w._xWin, w._win))
print(pwc.getWindowsWithTitle('Firefox', condition=pwc.Re.CONTAINS))
