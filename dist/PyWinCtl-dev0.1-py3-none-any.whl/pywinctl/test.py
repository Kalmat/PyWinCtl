import threading
import time

import pywinctl as pwc


class CheckWindows:

    def __init__(self, callback):
        self.worker = None
        self.callback = callback

    def start(self):
        self.worker = CheckWindowsWorker(self.callback)
        self.worker.daemon = True
        self.worker.start()

    def stop(self):
        self.worker.stop()
        self.worker.join()


class CheckWindowsWorker(threading.Thread):

    def __init__(self, callback):
        threading.Thread.__init__(self)

        self.callback = callback
        self.windows = [w.getHandle() for w in pwc.getAllWindows()]
        self.kill = threading.Event()
        self.interval = 0.1

    def run(self):

        while not self.kill.is_set():
            windows = [w.getHandle() for w in pwc.getAllWindows()]
            newWindows = [w for w in windows if w not in self.windows]
            if newWindows:
                print("NEW WINDOWS FOUND")
                self.callback(newWindows)
                self.windows = windows
            self.kill.wait(self.interval)

    def stop(self):
        self.kill.set()


def newWinNotification(newWindows):
    for handle in newWindows:
        print("NEW WINDOW", handle, pwc.Window(handle).title)


checkWindows = CheckWindows(newWinNotification)
checkWindows.start()
while True:
    try:
        time.sleep(1)
    except KeyboardInterrupt:
        break
checkWindows.stop()
