import pywinctl as pwc

import Quartz

# for win in pwc.getWindowsWithTitle("Proyectos"):
#     print("X:", win.left, "Y:", win.top, "WIDTH:", win.width, "HEIGHT:", win.height)

windows = Quartz.CGWindowListCopyWindowInfo(Quartz.kCGWindowListExcludeDesktopElements | Quartz.kCGWindowListOptionOnScreenOnly, Quartz. kCGNullWindowID)
print(windows)
for win in windows:
    if win.get(Quartz.kCGWindowOwnerName, "") == "Finder":
        bounds = win.get("kCGWindowBounds", None)
        print(bounds, bounds.get("X", None))
