import pywinctl as pwc
import time


def countChanged(names, screensInfo):
    print("MONITOR PLUGGED/UNPLUGGED:", names)
    for name in names:
        print("MONITORS INFO:", screensInfo[name])


def propsChanged(names, screensInfo):
    print("MONITOR CHANGED:", names)
    for name in names:
        print("MONITORS INFO:", screensInfo[name])


pwc.monitorsCtl.enableUpdate(monitorCountChanged=countChanged, monitorPropsChanged=propsChanged)
print("Plug/Unplug monitors, or change monitor properties while running")
print("Press Ctl-C to Quit")
while True:
    try:
        time.sleep(1)
    except KeyboardInterrupt:
        break
pwc.monitorsCtl.disableUpdate()
