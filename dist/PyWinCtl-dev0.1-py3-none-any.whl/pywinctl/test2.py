import threading
import time

import pywinctl as pwc


class _UpdateScreens:

    def __init__(self, interval: float = 0.3):
        self._worker: _UpdateScreensWorker = _UpdateScreensWorker(interval)
        self._worker.daemon = True
        self._worker.start()

    def getScreens(self):
        return self._worker.getScreens()

    def stop(self):
        self._worker.kill()
        self._worker.join()


class _UpdateScreensWorker(threading.Thread):

    def __init__(self, interval: float = 0.3):
        threading.Thread.__init__(self)

        self._screens = {}
        self._monitorsCount: int = 0
        self._kill = threading.Event()
        self._interval = interval

    def run(self):

        while not self._kill.is_set():
            self._screens = pwc.getAllScreens()
            self._kill.wait(self._interval)

    def getScreens(self):
        return self._screens

    def kill(self):
        self._kill.set()


_updateScreens = None


def monitorPlugDetection(enable: bool, interval: float = 0.3):
    """
    Enable this only in a multi-monitor setup in which monitors can be dynamically plugged or unplugged, and
    only if you need to keep track of these monitors to manipulate or control the window objects.

    If enabled, it will activate a separate thread which will periodically update the list of Monitors
    connected to or disconnected from the system.

    If disabled, the information on the monitors connected to the system will be static as it was when
    the window object was created (if a monitor is connected or disconnected afterward, it will not be detected)

    :param enable: Set to ''True'' to activate monitor plug/unplug detection.
                   Set to ''False'' to stop and kill the thread.
    :param interval: Wait interval for the thread loop in seconds (or fractions). Adapt to your needs. Defaults to 0.3.
    """
    global _updateScreens
    if enable:
        if _updateScreens is None:
            _updateScreens = _UpdateScreens(interval)
    else:
        if _updateScreens is not None:
            _updateScreens.stop()
            _updateScreens = None


def isMonitorPlugDetectionEnabled() -> bool:
    """
    Get the dynamic monitor plug/unplug detection status.

    :return: ''True'' if the dynamic monitor plug/unplug detection is enabled. ''False'' otherwise
    """
    global _updateScreens
    return bool(_updateScreens is not None)


def _getScreens():
    global _updateScreens
    if _updateScreens is not None:
        return _updateScreens.getScreens()
    else:
        return {}


monitorPlugDetection(True)
while True:
    try:
        time.sleep(1)
    except KeyboardInterrupt:
        break
monitorPlugDetection(False)
