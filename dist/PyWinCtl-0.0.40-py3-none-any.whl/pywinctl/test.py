import pywinctl as pwc

windows = pwc.getWindowsWithTitle("VLC", condition=pwc.Re.CONTAINS)
print(windows)
for w in windows:
    print(w.title)
    w.alwaysOnTop()

# Use w.alwaysOnTop(False) to stop alwaysOnTop behavior