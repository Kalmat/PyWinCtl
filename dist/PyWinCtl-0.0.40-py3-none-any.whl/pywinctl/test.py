import time

import Xlib
import ewmh
import pywinctl

DISP = Xlib.display.Display()
SCREEN = DISP.screen()
ROOT = DISP.screen().root
EWMH = ewmh.EWMH(_display=DISP, root=ROOT)


def sendBehind(hWnd):
    w = DISP.create_resource_object('window', hWnd.id)
    w.unmap()
    w.change_property(DISP.intern_atom('_NET_WM_WINDOW_TYPE', False), Xlib.Xatom.ATOM,
                      32, [DISP.intern_atom('_NET_WM_WINDOW_TYPE_DESKTOP', False), ],
                      Xlib.X.PropModeReplace)
    DISP.flush()
    w.map()

    # This will try to raise the desktop icons layer on top of the window
    # Ubuntu: "@!0,0;BDHF" is the new desktop icons NG extension
    # Mint: "Desktop" name is language-dependent. Using its class (nemo-desktop)
    # TODO: Test / find workaround in other OS
    desktop = _xlibGetAllWindows(title="@!0,0;BDHF", klass=('nemo-desktop', 'Nemo-desktop'))
    if not desktop:
        for w in EWMH.getClientListStacking():
            state = EWMH.getWmState(w)
            winType = EWMH.getWmWindowType(w)
            if '_NET_WM_STATE_SKIP_PAGER' in state and '_NET_WM_STATE_SKIP_TASKBAR' in state and '_NET_WM_WINDOW_TYPE_DESKTOP' in winType:
                desktop.append(w)
    for d in desktop:
        w = DISP.create_resource_object('window', d)
        w.raise_window()

    return '_NET_WM_WINDOW_TYPE_DESKTOP' in EWMH.getWmWindowType(hWnd, str=True)


def bringBack(hWnd):

    w = DISP.create_resource_object('window', hWnd)

    w.unmap()
    w.change_property(DISP.intern_atom('_NET_WM_WINDOW_TYPE', False), Xlib.Xatom.ATOM,
                      32, [DISP.intern_atom('_NET_WM_WINDOW_TYPE_NORMAL', False), ],
                      Xlib.X.PropModeReplace)
    DISP.flush()
    w.change_property(DISP.intern_atom('_NET_WM_STATE', False), Xlib.Xatom.ATOM,
                      32, [DISP.intern_atom('_NET_WM_STATE_FOCUSED', False), ],
                      Xlib.X.PropModeReplace)
    DISP.flush()
    w.map()
    EWMH.setActiveWindow(hWnd)
    EWMH.display.flush()
    return '_NET_WM_WINDOW_TYPE_NORMAL' in EWMH.getWmWindowType(hWnd, str=True)


def _xlibGetAllWindows(parent=None, title: str = "", klass=None):

    parent = parent or ROOT
    allWindows = [parent]

    def findit(hwnd):
        query = hwnd.query_tree()
        for child in query.children:
            allWindows.append(child)
            findit(child)

    findit(parent)
    if not title and not klass:
        return allWindows
    else:
        return [window for window in allWindows if ((title and window.get_wm_name() == title) or
                                                    (klass and window.get_wm_class() == klass))]


hWnd = pywinctl.getActiveWindow()
sendBehind(hWnd._hWnd)
time.sleep(3)
bringBack(hWnd._hWnd)
