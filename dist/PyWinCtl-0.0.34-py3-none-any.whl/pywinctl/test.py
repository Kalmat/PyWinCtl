# Machine learning
# https://medium.com/@ertuodaba/string-matching-using-machine-learning-with-python-matching-products-of-getir-and-carrefoursa-f8ce29d2959f

from fuzzywuzzy import fuzz
import difflib
import jellyfish
import numpy as np


def _levenshtein(seq1: str, seq2: str):
    # https://stackabuse.com/levenshtein-distance-and-text-similarity-in-python/
    # Adapted to return a similarity percentage, which is easier to define
    size_x = len(seq1) + 1
    size_y = len(seq2) + 1
    matrix = np.zeros((size_x, size_y))
    for x in range(size_x):
        matrix[x, 0] = x
    for y in range(size_y):
        matrix[0, y] = y

    for x in range(1, size_x):
        for y in range(1, size_y):
            if seq1[x - 1] == seq2[y - 1]:
                matrix[x, y] = min(
                    matrix[x - 1, y] + 1,
                    matrix[x - 1, y - 1],
                    matrix[x, y - 1] + 1
                )
            else:
                matrix[x, y] = min(
                    matrix[x - 1, y] + 1,
                    matrix[x - 1, y - 1] + 1,
                    matrix[x, y - 1] + 1
                )
    dist = matrix[size_x - 1, size_y - 1]
    return (1 - dist / max(len(seq1), len(seq2))) * 100


a = "PyWinCtl - python - 80x24"
b = "PyWinCtl - osascript - 80x56"

simpleRatio=fuzz.ratio(a, b)
print(simpleRatio)

partialRatio=fuzz.partial_ratio(a, b)
print(partialRatio)

TokensortRatio1=fuzz.ratio(a, b)
print(TokensortRatio1)

TokensortRatio2=fuzz.token_sort_ratio(a, b)
print(TokensortRatio2)

TokensortRatio3=fuzz.token_sort_ratio(a, b)
print(TokensortRatio3)

print(fuzz.QRatio(a, b, force_ascii=True, full_process=True))

TokensortRatio4=fuzz.token_set_ratio(a, b)
print(TokensortRatio4)

print(difflib.SequenceMatcher(a=a, b=b).ratio() * 100)
print((1 - jellyfish.damerau_levenshtein_distance(a, b) / max(len(a), len(b))) * 100)
print(_levenshtein(a, b))

print(difflib.get_close_matches("PyWinCtl - python - 80x24", ["PyWinCtl - osascript - 80x56", "Apple", "BBVA mail - Google Chrome", "Contacts", "PyWinctl Project Overview"]))
